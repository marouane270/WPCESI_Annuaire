﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WF_CESI
{

    public class API
    {
        public string title { get; set; }
        public string first { get; set; }
        public string last { get; set; }
    }

    public class Result
    {
        public API name { get; set; }
        public string phone { get; set; }
    }

    public class Root
    {
        public List<Result> results { get; set; }
    }

    
}

