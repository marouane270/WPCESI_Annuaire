﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_CESI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listeDesContactsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
        private void insérerContactToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Lien avec le formulaire NouveauContact
            InsertContact newFrm = new InsertContact();
            newFrm.MdiParent = this;
            newFrm.Show();
        }

        private void listeContactToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Lien avec le formulaire Liste des Contacts 
            ListeContact newFrm = new ListeContact();
            newFrm.MdiParent = this;
            newFrm.Show();
        }

        private void rechercheContactToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        

        private void Form1_Load(object sender, EventArgs e)
        {

            //Instantiation des collections de la classe globale
            Globale.lesContacts = new List<Contact>();
            Globale.lesResultats = new List<Result>();

            //Parametre Connexion SQLSERVER (N°Poste/Nom Base de donnée)
            Globale.LoadConnexion("HPG6-03", "AnnuaireBDD_CESI");



            //Appel de la procédure stockée LireLesContacts dans la classe bd
            bd.lireLesContacts();

            
           
            
        }

        private void nomToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Lien avec le formulaire de Recherche contact par le nom
            RechercheContactNom newFrm = new RechercheContactNom();
            newFrm.MdiParent = this;
            newFrm.Show();
        }

        private void dateDEntrééToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //Lien avec le formulaire de Recherche contact par la date d'entrée
            RechercheContactDate newFrm = new RechercheContactDate();
            newFrm.MdiParent = this;
            newFrm.Show();
        }
    }
}
