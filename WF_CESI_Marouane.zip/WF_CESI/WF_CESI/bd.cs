﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WF_CESI
{
    public class bd
    {
        public static void lireLesContacts()
        {
            Globale.lesContacts.Clear();

            //objet SQLCommand pour définir la procédure stockée à utiliser
            SqlCommand maRequete = new SqlCommand("prc_LireContacts", Globale.cnx);

            // exécuter la procedure stockée dans un curseur 
            SqlDataReader SqlExec = maRequete.ExecuteReader();

            //boucle de lecture des clients avec ajout dans la collection
            while (SqlExec.Read())
            {
                int id = int.Parse(SqlExec["Id"].ToString());
                string nom = SqlExec["Nom"].ToString();
                string prenom = SqlExec["Prenom"].ToString();
                string tel = SqlExec["Tel"].ToString();
                string service = SqlExec["Service"].ToString();
                string dateEntree = SqlExec["DateEntree"].ToString();



                Contact unContact = new Contact(id, nom, prenom, tel, service, DateTime.Parse(dateEntree));

                Globale.lesContacts.Add(unContact);
            }
        }

        public static bool InsertContact(string nom, string prenom, string tel, string service, DateTime dateEntree)
        {


            SqlCommand maRequete = new SqlCommand("prc_InsertContact", Globale.cnx);
            maRequete.CommandType = System.Data.CommandType.StoredProcedure;


            SqlParameter nomContact = new SqlParameter("@nom", System.Data.SqlDbType.NVarChar, 255);
            nomContact.Value = nom;
            maRequete.Parameters.Add(nomContact);

            SqlParameter prenomContact = new SqlParameter("@prenom", System.Data.SqlDbType.NVarChar, 255);
            prenomContact.Value = prenom;
            maRequete.Parameters.Add(prenomContact);

            SqlParameter telContact = new SqlParameter("@tel", System.Data.SqlDbType.NVarChar, 255);
            telContact.Value = tel;
            maRequete.Parameters.Add(telContact);

            SqlParameter serviceContact = new SqlParameter("@service", System.Data.SqlDbType.NVarChar, 255);
            serviceContact.Value = service;
            maRequete.Parameters.Add(serviceContact);

            SqlParameter DateEntree = new SqlParameter("@dateEntree", System.Data.SqlDbType.Date);
            DateEntree.Value = dateEntree;
            maRequete.Parameters.Add(DateEntree);


            maRequete.ExecuteNonQuery();

            return true;
        }
    }
}
