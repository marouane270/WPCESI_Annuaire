﻿namespace WF_CESI
{
    partial class RechercheContactNom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbNom = new System.Windows.Forms.ComboBox();
            this.lvRechercheContact = new System.Windows.Forms.ListView();
            this.Prénom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Téléphone = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Service = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(144, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Nom : ";
            // 
            // cbNom
            // 
            this.cbNom.FormattingEnabled = true;
            this.cbNom.Location = new System.Drawing.Point(274, 83);
            this.cbNom.Name = "cbNom";
            this.cbNom.Size = new System.Drawing.Size(213, 24);
            this.cbNom.TabIndex = 2;
            this.cbNom.SelectedIndexChanged += new System.EventHandler(this.cbNom_SelectedIndexChanged);
            // 
            // lvRechercheContact
            // 
            this.lvRechercheContact.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Prénom,
            this.Téléphone,
            this.Service,
            this.columnHeader4});
            this.lvRechercheContact.Location = new System.Drawing.Point(68, 154);
            this.lvRechercheContact.Name = "lvRechercheContact";
            this.lvRechercheContact.Size = new System.Drawing.Size(637, 257);
            this.lvRechercheContact.TabIndex = 3;
            this.lvRechercheContact.UseCompatibleStateImageBehavior = false;
            this.lvRechercheContact.View = System.Windows.Forms.View.Details;
            // 
            // Prénom
            // 
            this.Prénom.Text = "Prénom";
            this.Prénom.Width = 184;
            // 
            // Téléphone
            // 
            this.Téléphone.Text = "Téléphone";
            this.Téléphone.Width = 115;
            // 
            // Service
            // 
            this.Service.Text = "Service";
            this.Service.Width = 152;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Date d\'Entrée";
            this.columnHeader4.Width = 114;
            // 
            // RechercheContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lvRechercheContact);
            this.Controls.Add(this.cbNom);
            this.Controls.Add(this.label1);
            this.Name = "RechercheContact";
            this.Text = "RechercheContact";
            this.Load += new System.EventHandler(this.RechercheContact_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbNom;
        private System.Windows.Forms.ListView lvRechercheContact;
        private System.Windows.Forms.ColumnHeader Prénom;
        private System.Windows.Forms.ColumnHeader Téléphone;
        private System.Windows.Forms.ColumnHeader Service;
        private System.Windows.Forms.ColumnHeader columnHeader4;
    }
}