﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WF_CESI
{
    class Contact
    {
        public int id;
        public string nom;
        public string prenom;
        public string tel;
        public string service;
        public DateTime dateEntree;

        //constructeur de Contact
        public Contact(int leId, string leNom, string lePrenom, string leTel, string leService, DateTime laDateEntree)
        {
            this.id = leId;
            this.nom = leNom;
            this.prenom = lePrenom;
            this.tel = leTel;
            this.service = leService;
            this.dateEntree = laDateEntree;
        }

        public int getId() { return this.id; }
        public string getNom() { return this.nom; }
        public string getPrenom() { return this.prenom; }
        public string getTel() { return this.tel; }
        public string getService() { return this.service; }
        public DateTime getDateEntree() { return this.dateEntree; }

        public void setNom(string leNom) { this.nom = leNom; }
        public void setPrenom(string lePrenom) { this.prenom = lePrenom; }
        public void setTel(string leTel) { this.tel = leTel; }
        public void setService(string leService) { this.service = leService; }
        public void setDateEntree(DateTime laDateEntree) { this.dateEntree = laDateEntree; }
    }
}

