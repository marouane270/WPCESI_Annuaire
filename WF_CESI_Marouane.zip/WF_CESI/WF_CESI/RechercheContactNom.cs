﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_CESI
{
    public partial class RechercheContactNom : Form
    {
        public RechercheContactNom()
        {
            InitializeComponent();
        }

        private void cbNom_SelectedIndexChanged(object sender, EventArgs e)
        {
            lvRechercheContact.Items.Clear();
            foreach (Contact unContact in Globale.lesContacts)
            {
                if (cbNom.SelectedIndex + 1 == unContact.getId())
                {
                    ListViewItem uneLigne = new ListViewItem();
                    uneLigne.Text = (unContact.getPrenom());
                    uneLigne.SubItems.Add(unContact.getTel().ToString());
                    uneLigne.SubItems.Add(unContact.getService());
                    uneLigne.SubItems.Add(unContact.getDateEntree().ToShortDateString());
                    lvRechercheContact.Items.Add(uneLigne);
                }
            }
        }

        private void RechercheContact_Load(object sender, EventArgs e)
        {
            //Alimentation ComboBox
            foreach (Contact unContact in Globale.lesContacts)
            {
                cbNom.Items.Add(unContact.getNom());
            }


            
        }
    }
}
