﻿namespace WF_CESI
{
    partial class InsertContact
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tbNom = new System.Windows.Forms.TextBox();
            this.tbTel = new System.Windows.Forms.TextBox();
            this.tbService = new System.Windows.Forms.TextBox();
            this.tbPrenom = new System.Windows.Forms.TextBox();
            this.dtpDateEntree = new System.Windows.Forms.DateTimePicker();
            this.btContact = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(116, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(45, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Nom :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(116, 199);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "Prenom :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(116, 241);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(100, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "N°Téléphone :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(118, 286);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(63, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "Service :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(116, 104);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "Date Entrée :";
            // 
            // tbNom
            // 
            this.tbNom.Enabled = false;
            this.tbNom.Location = new System.Drawing.Point(280, 159);
            this.tbNom.Name = "tbNom";
            this.tbNom.Size = new System.Drawing.Size(168, 22);
            this.tbNom.TabIndex = 5;
            // 
            // tbTel
            // 
            this.tbTel.Enabled = false;
            this.tbTel.Location = new System.Drawing.Point(280, 238);
            this.tbTel.Name = "tbTel";
            this.tbTel.Size = new System.Drawing.Size(168, 22);
            this.tbTel.TabIndex = 6;
            // 
            // tbService
            // 
            this.tbService.Enabled = false;
            this.tbService.Location = new System.Drawing.Point(280, 283);
            this.tbService.Name = "tbService";
            this.tbService.Size = new System.Drawing.Size(168, 22);
            this.tbService.TabIndex = 7;
            this.tbService.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // tbPrenom
            // 
            this.tbPrenom.Enabled = false;
            this.tbPrenom.Location = new System.Drawing.Point(280, 196);
            this.tbPrenom.Name = "tbPrenom";
            this.tbPrenom.Size = new System.Drawing.Size(168, 22);
            this.tbPrenom.TabIndex = 9;
            // 
            // dtpDateEntree
            // 
            this.dtpDateEntree.Location = new System.Drawing.Point(270, 99);
            this.dtpDateEntree.Name = "dtpDateEntree";
            this.dtpDateEntree.Size = new System.Drawing.Size(200, 22);
            this.dtpDateEntree.TabIndex = 10;
            // 
            // btContact
            // 
            this.btContact.Location = new System.Drawing.Point(582, 199);
            this.btContact.Name = "btContact";
            this.btContact.Size = new System.Drawing.Size(125, 56);
            this.btContact.TabIndex = 12;
            this.btContact.Text = "Nouveau Contact";
            this.btContact.UseVisualStyleBackColor = true;
            this.btContact.Click += new System.EventHandler(this.btContact_Click);
            // 
            // InsertContact
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btContact);
            this.Controls.Add(this.dtpDateEntree);
            this.Controls.Add(this.tbPrenom);
            this.Controls.Add(this.tbService);
            this.Controls.Add(this.tbTel);
            this.Controls.Add(this.tbNom);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "InsertContact";
            this.Text = "InsertContact";
            this.Load += new System.EventHandler(this.InsertContact_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbNom;
        private System.Windows.Forms.TextBox tbTel;
        private System.Windows.Forms.TextBox tbService;
        private System.Windows.Forms.TextBox tbPrenom;
        private System.Windows.Forms.DateTimePicker dtpDateEntree;
        private System.Windows.Forms.Button btContact;
    }
}