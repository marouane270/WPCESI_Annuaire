﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_CESI
{
    public partial class ListeContact : Form
    {
        public ListeContact()
        {
            InitializeComponent();
        }
       



        private void ListeContact_Load(object sender, EventArgs e)
        {
            
            
            Globale.lesContacts = new List<Contact>();
            Globale.lesResultats = new List<Result>();

            
            Globale.LoadConnexion("HPG6-03", "AnnuaireBDD_CESI");


            
            bd.lireLesContacts();


            
            lvContact.Items.Clear();
            //Parcours dans la classe Contact pour afficher informations dans Listview
            foreach (Contact unContact in Globale.lesContacts)
            {
                ListViewItem uneLigne = new ListViewItem();
                uneLigne.Text = unContact.getNom();
                uneLigne.SubItems.Add(unContact.getPrenom());
                uneLigne.SubItems.Add(unContact.getTel().ToString());
                uneLigne.SubItems.Add(unContact.getService());
                uneLigne.SubItems.Add(unContact.getDateEntree().ToShortDateString());
                lvContact.Items.Add(uneLigne);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}
