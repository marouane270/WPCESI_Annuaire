﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_CESI
{
    public partial class RechercheContactDate : Form
    {
        public RechercheContactDate()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
        }

        private void btValider_Click(object sender, EventArgs e)
        {
            lvRechercheContactDate.Items.Clear();

            foreach (Contact unContact in Globale.lesContacts)
            {

                if (comboBox1.Text == unContact.getDateEntree().ToShortDateString())
                {
                    ListViewItem uneLigne = new ListViewItem();
                    uneLigne.Text = (unContact.getNom());
                    uneLigne.SubItems.Add(unContact.getPrenom());
                    uneLigne.SubItems.Add(unContact.getTel().ToString());
                    uneLigne.SubItems.Add(unContact.getService());

                    lvRechercheContactDate.Items.Add(uneLigne);

                }

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void RechercheContactDate_Load(object sender, EventArgs e)
        {
            //Parcours pour alimenter le comboBox
            foreach (Contact unContact in Globale.lesContacts)
            {
                comboBox1.Items.Add(unContact.getDateEntree());
                
            }

        }

        private void lvRechercheContactDate_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
