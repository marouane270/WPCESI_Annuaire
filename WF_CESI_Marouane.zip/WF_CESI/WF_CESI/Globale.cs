﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WF_CESI
{
    class Globale
    {   //Collection classe Contact 
        public static List<Contact> lesContacts;
        public static List<Result> lesResultats;
        public static SqlConnection cnx;

        public static void LoadConnexion(string HoteName, string dateBaseName)
        {   //Connexion à SQLSERVEUR
            Globale.cnx = new System.Data.SqlClient.SqlConnection();
            Globale.cnx.ConnectionString = "Data Source=" + HoteName + "\\SQLEXPRESS;Initial Catalog=" + dateBaseName + ";Integrated Security=True;MultipleActiveResultSets=True";
            Globale.cnx.Open();

        }
    }
}
