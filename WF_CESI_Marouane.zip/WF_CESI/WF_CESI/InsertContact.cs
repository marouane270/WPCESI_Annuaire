﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WF_CESI
{
    public partial class InsertContact : Form
    {
        public InsertContact()
        {
            InitializeComponent();
        }

        public async Task<Result> ReadUser()
        {
            //Appel de l'API 
            Uri uri = new Uri("https://randomuser.me/api/?inc=name,phone");

            HttpClient myClient = new HttpClient();

            HttpResponseMessage response = await myClient.GetAsync(uri);

            Root leRoot = null;
            if (response.IsSuccessStatusCode)
            {
                string content = await response.Content.ReadAsStringAsync();
                leRoot = JsonConvert.DeserializeObject<Root>(content);

            }

            return leRoot.results[0];
        }

        private void InsertContact_Load(object sender, EventArgs e)
        {
            
            Globale.lesContacts = new List<Contact>();
            Globale.lesResultats = new List<Result>();

            //Au premier paramètre mettez le nom de votre poste
            Globale.LoadConnexion("HPG6-03", "AnnuaireBDD_CESI");

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btContact_Click(object sender, EventArgs e)
        {
       

            //Exécution de l'API
            var t = Task.Run(() => ReadUser());

            t.Wait();

            //Liste des Services
            string[] service = { "Informatique", "Ressources Humaines", "Commercial", "Client", "Comptabilité" };
            Random serv = new Random();
            string serviceRslt = service[serv.Next(0, service.Length)];

            //Appel de la procédure stockée InsertContact avec la classe bd
            bd.InsertContact(t.Result.name.last, t.Result.name.first, t.Result.phone, serviceRslt, dtpDateEntree.Value);


            bd.lireLesContacts();
            foreach (Contact unContact in Globale.lesContacts)
            {
                tbNom.Text = unContact.getNom();
                tbPrenom.Text = unContact.getPrenom();
                tbTel.Text = unContact.getTel();
                tbService.Text = unContact.getService();
                dtpDateEntree.Value = DateTime.Now;
            }

            MessageBox.Show("Le contact a bien été enregisté !");


        }

        private void btEnreg_Click(object sender, EventArgs e)
        {
            

        }
    }
}
